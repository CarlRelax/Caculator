#include "calculate.h"
#include <QDebug>
Calculate::Calculate(QObject *parent)
    : QObject{parent}
{}

void Calculate::Calc(const QString &num_str, const CalculateType &type)
{
    qWarning()<<num_str<<type;
    double num = num_str.toDouble();
    switch (type_) {
    case ADD:
        tmp_result_ += num;
        break;
    case SUB:
        tmp_result_ -= num;
        break;
    case MUL:
        tmp_result_ *= num;
        break;
    case DIV:
        tmp_result_ /= num;
        break;
    default:
        qWarning()<<"type is wrong!";
        break;
    }
    type_ = type;
    emit SigCalculateOut(QString::number(tmp_result_));
}

Calculate::CalculateType Calculate::type() const
{
    return type_;
}

void Calculate::setType(CalculateType newType)
{
    if (type_ == newType)
        return;
    type_ = newType;
    emit typeChanged();
}

double Calculate::tmp_result() const
{
    return tmp_result_;
}

void Calculate::setTmp_result(double newTmp_result)
{
    if (qFuzzyCompare(tmp_result_, newTmp_result))
        return;
    tmp_result_ = newTmp_result;
    emit tmp_resultChanged();
}

