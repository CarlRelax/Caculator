#ifndef CALCULATE_H
#define CALCULATE_H

#include <QObject>
#include <QQmlEngine>
#include <QString>

class Calculate : public QObject
{
    Q_OBJECT
public:
    explicit Calculate(QObject *parent = nullptr);
    enum CalculateType
    {
        ADD = 0,
        SUB,
        MUL,
        DIV
    };
public slots:
    void Calc(const QString& num_str, const CalculateType& type);

    CalculateType type() const;
    void setType(CalculateType newType);

    double tmp_result() const;
    void setTmp_result(double newTmp_result);

private:
    // QVector<double> calculate_nums_;
    double tmp_result_ = 0.0;
    CalculateType type_ = ADD;

    Q_PROPERTY(CalculateType type READ type WRITE setType NOTIFY typeChanged FINAL)

    Q_PROPERTY(double tmp_result READ tmp_result WRITE setTmp_result NOTIFY tmp_resultChanged FINAL)

signals:
    void SigCalculateOut(const QString& result);
    void typeChanged();
    void tmp_resultChanged();
};

#endif // CALCULATE_H
