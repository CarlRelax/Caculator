#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "calculate.h"
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/Main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if(!obj && url == objUrl)
            QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    qmlRegisterType<Calculate>("Calculate",1,0,"Calculate");
    // engine.loadFromModule("calculator", "Main");
    engine.load(url);
    return app.exec();
}
